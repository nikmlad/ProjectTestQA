package ui.pages;

import com.codeborne.selenide.SelenideElement;
import ui.components.profile.ProfileAccordion;

import static com.codeborne.selenide.Selenide.$;

public class ProfilePage {

    private final SelenideElement root = $("[data-testid='profile-page']");

    public ProfileAccordion profileAccordion() {
        return new ProfileAccordion(root.$("[data-component='accordion']"));
    }
}

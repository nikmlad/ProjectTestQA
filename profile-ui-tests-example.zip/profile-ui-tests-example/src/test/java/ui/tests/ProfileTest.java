package ui.tests;

import org.junit.jupiter.api.Test;
import ui.pages.ProfilePage;

import static com.codeborne.selenide.Selenide.open;

public class ProfileTest {

    @Test
    void canFillProfileAccordion() {
        ProfilePage profilePage = open("/profile", ProfilePage.class);

        var accordion = profilePage.profileAccordion();

        var personal = accordion.personalInformation();
        personal.firstName().setValue("Anna");
        personal.lastName().setValue("Smith");
        personal.gender().select("Female");
        personal.receiveOffers().check();
        personal.next();

        var address = accordion.address();
        address.city().setValue("Vienna");
        address.street().setValue("Mariahilfer Strasse");
        address.postalCode().setValue("1060");
        address.country().select("Austria");
        address.next();

        var documents = accordion.documents();
        documents.documentType().select("Passport");
        documents.passportNumber().setValue("AA123456");
        documents.confirmed().check();
        documents.next();

        var preferences = accordion.preferences();
        preferences.language().select("English");
        preferences.darkMode().check();
        preferences.next();

        var security = accordion.security();
        security.recoveryEmail().setValue("anna.backup@example.com");
        security.twoFactorAuth().check();
        security.next();

        var notifications = accordion.notifications();
        notifications.notificationFrequency().select("Weekly");
        notifications.emailNotifications().check();
        notifications.smsNotifications().uncheck();
        notifications.next();
    }
}

package ui.components.fields;

import com.codeborne.selenide.SelenideElement;
import ui.components.base.BaseComponent;

import static com.codeborne.selenide.Condition.*;
import static java.lang.String.format;

public class Checkbox extends BaseComponent {

    private final String name;

    public Checkbox(SelenideElement parent, String name) {
        super(parent.$x(format(
                ".//*[@data-component='checkbox'][.//label[contains(normalize-space(), %s)]]",
                xpathLiteral(name)
        )));
        this.name = name;
    }

    public Checkbox check() {
        input().shouldBe(visible, enabled).setSelected(true);
        return this;
    }

    public Checkbox uncheck() {
        input().shouldBe(visible, enabled).setSelected(false);
        return this;
    }

    public Checkbox shouldBeChecked() {
        input().shouldBe(checked);
        return this;
    }

    public Checkbox shouldNotBeChecked() {
        input().shouldNotBe(checked);
        return this;
    }

    public Checkbox shouldBeVisible() {
        root.shouldBe(visible).shouldHave(text(name));
        input().shouldBe(visible);
        return this;
    }

    private SelenideElement input() {
        return root.$("input[type='checkbox']");
    }

    private static String xpathLiteral(String value) {
        if (!value.contains("'")) {
            return "'" + value + "'";
        }
        if (!value.contains("\"")) {
            return "\"" + value + "\"";
        }
        return "concat('" + value.replace("'", "', \"'\", '") + "')";
    }
}

package ui.components.fields;

import com.codeborne.selenide.SelenideElement;
import ui.components.base.BaseComponent;

import static com.codeborne.selenide.Condition.*;
import static java.lang.String.format;

public class TextField extends BaseComponent {

    private final String name;

    public TextField(SelenideElement parent, String name) {
        super(parent.$x(format(
                ".//*[@data-component='text-field'][.//label[normalize-space()=%s]]",
                xpathLiteral(name)
        )));
        this.name = name;
    }

    public TextField setValue(String value) {
        input().shouldBe(visible, enabled).setValue(value);
        return this;
    }

    public TextField clear() {
        input().shouldBe(visible, enabled).clear();
        return this;
    }

    public String value() {
        return input().getValue();
    }

    public TextField shouldHaveValue(String expectedValue) {
        input().shouldHave(value(expectedValue));
        return this;
    }

    public TextField shouldBeVisible() {
        root.shouldBe(visible);
        label().shouldHave(exactText(name));
        input().shouldBe(visible);
        return this;
    }

    private SelenideElement label() {
        return root.$("label");
    }

    private SelenideElement input() {
        return root.$("input");
    }

    private static String xpathLiteral(String value) {
        if (!value.contains("'")) {
            return "'" + value + "'";
        }
        if (!value.contains("\"")) {
            return "\"" + value + "\"";
        }
        return "concat('" + value.replace("'", "', \"'\", '") + "')";
    }
}

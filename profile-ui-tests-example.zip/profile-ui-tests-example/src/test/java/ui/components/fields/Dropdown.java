package ui.components.fields;

import com.codeborne.selenide.SelenideElement;
import ui.components.base.BaseComponent;

import static com.codeborne.selenide.Condition.*;
import static java.lang.String.format;

public class Dropdown extends BaseComponent {

    private final String name;

    public Dropdown(SelenideElement parent, String name) {
        super(parent.$x(format(
                ".//*[@data-component='dropdown'][.//label[normalize-space()=%s]]",
                xpathLiteral(name)
        )));
        this.name = name;
    }

    public Dropdown select(String option) {
        select().shouldBe(visible, enabled).selectOption(option);
        return this;
    }

    public Dropdown shouldHaveSelectedValue(String expectedValue) {
        select().getSelectedOption().shouldHave(text(expectedValue));
        return this;
    }

    public Dropdown shouldBeVisible() {
        root.shouldBe(visible);
        label().shouldHave(exactText(name));
        select().shouldBe(visible);
        return this;
    }

    private SelenideElement label() {
        return root.$("label");
    }

    private SelenideElement select() {
        return root.$("select");
    }

    private static String xpathLiteral(String value) {
        if (!value.contains("'")) {
            return "'" + value + "'";
        }
        if (!value.contains("\"")) {
            return "\"" + value + "\"";
        }
        return "concat('" + value.replace("'", "', \"'\", '") + "')";
    }
}

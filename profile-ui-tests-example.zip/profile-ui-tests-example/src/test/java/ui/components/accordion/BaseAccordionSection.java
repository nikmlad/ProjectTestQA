package ui.components.accordion;

import com.codeborne.selenide.SelenideElement;
import ui.components.base.BaseComponent;
import ui.components.controls.Button;
import ui.components.fields.Checkbox;
import ui.components.fields.Dropdown;
import ui.components.fields.TextField;

import static com.codeborne.selenide.Condition.*;
import static java.lang.String.format;

public abstract class BaseAccordionSection extends BaseComponent {

    private final String title;

    protected BaseAccordionSection(SelenideElement accordionRoot, String title) {
        super(accordionRoot.$x(format(
                ".//*[@data-component='accordion-section'][.//*[@data-testid='accordion-header']//*[normalize-space()=%s]]",
                xpathLiteral(title)
        )));
        this.title = title;
    }

    public BaseAccordionSection expand() {
        if (!isExpanded()) {
            toggleButton().shouldBe(visible, enabled).click();
        }
        content().shouldBe(visible);
        return this;
    }

    public BaseAccordionSection collapse() {
        if (isExpanded()) {
            toggleButton().shouldBe(visible, enabled).click();
        }
        content().shouldNotBe(visible);
        return this;
    }

    public BaseAccordionSection shouldBeExpanded() {
        content().shouldBe(visible);
        return this;
    }

    public BaseAccordionSection shouldBeCollapsed() {
        content().shouldNotBe(visible);
        return this;
    }

    public BaseAccordionSection shouldHaveTitle() {
        header().shouldHave(text(title));
        return this;
    }

    public BaseAccordionSection next() {
        expand();
        content().$("[data-testid='next-button']")
                .shouldBe(visible, enabled)
                .click();
        return this;
    }

    protected TextField textField(String name) {
        expand();
        return new TextField(content(), name);
    }

    protected Dropdown dropdown(String name) {
        expand();
        return new Dropdown(content(), name);
    }

    protected Checkbox checkbox(String name) {
        expand();
        return new Checkbox(content(), name);
    }

    protected Button button(String name) {
        expand();
        return new Button(content(), name);
    }

    protected SelenideElement content() {
        return root.$("[data-testid='accordion-content']");
    }

    private boolean isExpanded() {
        return content().isDisplayed();
    }

    private SelenideElement header() {
        return root.$("[data-testid='accordion-header']");
    }

    private SelenideElement toggleButton() {
        return header().$("[data-testid='collapse-button']");
    }

    private static String xpathLiteral(String value) {
        if (!value.contains("'")) {
            return "'" + value + "'";
        }
        if (!value.contains("\"")) {
            return "\"" + value + "\"";
        }
        return "concat('" + value.replace("'", "', \"'\", '") + "')";
    }
}

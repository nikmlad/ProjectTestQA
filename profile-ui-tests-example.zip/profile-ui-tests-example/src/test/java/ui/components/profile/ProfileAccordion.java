package ui.components.profile;

import com.codeborne.selenide.SelenideElement;
import ui.components.base.BaseComponent;

public class ProfileAccordion extends BaseComponent {

    public ProfileAccordion(SelenideElement root) {
        super(root);
    }

    public PersonalInformationSection personalInformation() {
        return new PersonalInformationSection(root);
    }

    public AddressSection address() {
        return new AddressSection(root);
    }

    public DocumentsSection documents() {
        return new DocumentsSection(root);
    }

    public PreferencesSection preferences() {
        return new PreferencesSection(root);
    }

    public SecuritySection security() {
        return new SecuritySection(root);
    }

    public NotificationsSection notifications() {
        return new NotificationsSection(root);
    }
}

package ui.components.profile;

import com.codeborne.selenide.SelenideElement;
import ui.components.accordion.BaseAccordionSection;
import ui.components.fields.Checkbox;
import ui.components.fields.TextField;

public class SecuritySection extends BaseAccordionSection {

    public SecuritySection(SelenideElement accordionRoot) {
        super(accordionRoot, "Security");
    }

    public TextField recoveryEmail() {
        return textField("Recovery email");
    }

    public Checkbox twoFactorAuth() {
        return checkbox("Two-factor authentication");
    }
}

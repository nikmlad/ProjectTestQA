package ui.components.profile;

import com.codeborne.selenide.SelenideElement;
import ui.components.accordion.BaseAccordionSection;
import ui.components.fields.Dropdown;
import ui.components.fields.TextField;

public class AddressSection extends BaseAccordionSection {

    public AddressSection(SelenideElement accordionRoot) {
        super(accordionRoot, "Address");
    }

    public TextField city() {
        return textField("City");
    }

    public TextField street() {
        return textField("Street");
    }

    public TextField postalCode() {
        return textField("Postal code");
    }

    public Dropdown country() {
        return dropdown("Country");
    }
}

package ui.components.profile;

import com.codeborne.selenide.SelenideElement;
import ui.components.accordion.BaseAccordionSection;
import ui.components.fields.Checkbox;
import ui.components.fields.Dropdown;

public class NotificationsSection extends BaseAccordionSection {

    public NotificationsSection(SelenideElement accordionRoot) {
        super(accordionRoot, "Notifications");
    }

    public Dropdown notificationFrequency() {
        return dropdown("Notification frequency");
    }

    public Checkbox emailNotifications() {
        return checkbox("Email notifications");
    }

    public Checkbox smsNotifications() {
        return checkbox("SMS notifications");
    }
}

package ui.components.profile;

import com.codeborne.selenide.SelenideElement;
import ui.components.accordion.BaseAccordionSection;
import ui.components.fields.Checkbox;
import ui.components.fields.Dropdown;

public class PreferencesSection extends BaseAccordionSection {

    public PreferencesSection(SelenideElement accordionRoot) {
        super(accordionRoot, "Preferences");
    }

    public Dropdown language() {
        return dropdown("Language");
    }

    public Checkbox darkMode() {
        return checkbox("Dark mode");
    }
}

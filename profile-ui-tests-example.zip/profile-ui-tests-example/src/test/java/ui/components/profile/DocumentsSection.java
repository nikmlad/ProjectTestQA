package ui.components.profile;

import com.codeborne.selenide.SelenideElement;
import ui.components.accordion.BaseAccordionSection;
import ui.components.fields.Checkbox;
import ui.components.fields.Dropdown;
import ui.components.fields.TextField;

public class DocumentsSection extends BaseAccordionSection {

    public DocumentsSection(SelenideElement accordionRoot) {
        super(accordionRoot, "Documents");
    }

    public Dropdown documentType() {
        return dropdown("Document type");
    }

    public TextField passportNumber() {
        return textField("Passport number");
    }

    public Checkbox confirmed() {
        return checkbox("Confirmed");
    }
}

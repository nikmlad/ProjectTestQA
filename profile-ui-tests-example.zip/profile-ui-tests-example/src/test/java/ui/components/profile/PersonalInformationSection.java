package ui.components.profile;

import com.codeborne.selenide.SelenideElement;
import ui.components.accordion.BaseAccordionSection;
import ui.components.fields.Checkbox;
import ui.components.fields.Dropdown;
import ui.components.fields.TextField;

public class PersonalInformationSection extends BaseAccordionSection {

    public PersonalInformationSection(SelenideElement accordionRoot) {
        super(accordionRoot, "Personal information");
    }

    public TextField firstName() {
        return textField("First name");
    }

    public TextField lastName() {
        return textField("Last name");
    }

    public Dropdown gender() {
        return dropdown("Gender");
    }

    public Checkbox receiveOffers() {
        return checkbox("Receive offers");
    }
}

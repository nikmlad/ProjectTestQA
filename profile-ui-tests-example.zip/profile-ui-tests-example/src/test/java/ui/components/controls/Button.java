package ui.components.controls;

import com.codeborne.selenide.SelenideElement;
import ui.components.base.BaseComponent;

import static com.codeborne.selenide.Condition.*;
import static java.lang.String.format;

public class Button extends BaseComponent {

    private final String name;

    public Button(SelenideElement parent, String name) {
        super(parent.$x(format(
                ".//button[normalize-space()=%s or @data-testid=%s]",
                xpathLiteral(name),
                xpathLiteral(name)
        )));
        this.name = name;
    }

    public Button click() {
        root.shouldBe(visible, enabled).click();
        return this;
    }

    public Button shouldBeVisible() {
        root.shouldBe(visible);
        return this;
    }

    public Button shouldHaveName() {
        root.shouldHave(text(name));
        return this;
    }

    private static String xpathLiteral(String value) {
        if (!value.contains("'")) {
            return "'" + value + "'";
        }
        if (!value.contains("\"")) {
            return "\"" + value + "\"";
        }
        return "concat('" + value.replace("'", "', \"'\", '") + "')";
    }
}

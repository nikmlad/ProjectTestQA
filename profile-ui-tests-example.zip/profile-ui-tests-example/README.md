# Profile UI Tests Example

Пример архитектуры UI web tests на Java + Selenide для сложного экрана с аккордеоном.

## Идея

```text
Test
 ↓
Page Object
 ↓
Business components / Accordion sections
 ↓
Primitive UI components: TextField, Dropdown, Checkbox, Button
```

## Пример использования

```java
ProfilePage profilePage = open("/profile", ProfilePage.class);

var personal = profilePage.profileAccordion().personalInformation();
personal.firstName().setValue("Anna");
personal.gender().select("Female");
personal.receiveOffers().check();
personal.next();
```

## Ожидаемая HTML-идея

Компоненты ищутся внутри родителя по стабильным атрибутам:

- `data-testid="profile-page"`
- `data-component="accordion"`
- `data-component="accordion-section"`
- `data-testid="accordion-header"`
- `data-testid="accordion-content"`
- `data-component="text-field"`
- `data-component="dropdown"`
- `data-component="checkbox"`
- `data-testid="next-button"`

## Запуск

Это архитектурный пример. Чтобы тест реально запускался, укажи настоящий `baseUrl` и URL страницы в `ProfileTest`.

```bash
mvn test
```
